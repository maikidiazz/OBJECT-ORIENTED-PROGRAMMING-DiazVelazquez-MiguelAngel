create database if not exists login_system_db;
use login_system_db;

create table if not exists users (
	id_user INT auto_increment primary key,
	username VARCHAR(50) not null unique,
	password varchar(256) not null,
	nombre varchar (50) not null
);
insert into users (username, password, nombre ) values ('admin', 'admin!123', 'Super Admin')

create table if not exists products (
    id_product INT auto_increment primary key,
    nombre VARCHAR(100) not null,
    precio DECIMAL(10,2) not null,
    stock INT not null
);
