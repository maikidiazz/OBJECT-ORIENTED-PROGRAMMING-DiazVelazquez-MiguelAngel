import tkinter as tk
from tkinter import ttk, messagebox
from decimal import Decimal, InvalidOperation
from Models.products_models import Product


class DashboardVentana:
    def __init__(self, root, nombre_usuario):
        self.root = root
        self.root.title("Panel de control - Inventario")
        self.root.minsize(800, 500)
        self.root.geometry("950x550")
        self.root.resizable(True, True)
        self.root.configure(bg="#EDF5F0")

        # Encabezado
        encabezado = tk.Frame(root, bg="#EDF5F0")
        encabezado.pack(fill="x", padx=20, pady=15)

        tk.Button(
            encabezado,
            text="Cerrar sesión",
            bg="#378562",
            fg="white",
            relief="flat",
            padx=12,
            pady=7,
            command=self._cerrar_sesion
        ).pack(side="right")

        tk.Label(
            encabezado,
            text=f"Bienvenido/a, {nombre_usuario}",
            font=("Arial", 16, "bold"),
            bg="#EDF5F0",
            fg="#245C45",
            wraplength=580,
            justify="left"
        ).pack(side="left")

        # Pestañas
        pestañas = ttk.Notebook(root)
        pestañas.pack(
            fill="both", expand=True,
            padx=20, pady=(0, 20)
        )

        inicio = tk.Frame(pestañas, bg="white")
        inventario = tk.Frame(pestañas, bg="#EDF5F0")

        pestañas.add(inicio, text="Inicio")
        pestañas.add(inventario, text="Inventario de productos")

        tk.Label(
            inicio,
            text="Control de inventario",
            font=("Arial", 22, "bold"),
            bg="white",
            fg="#245C45"
        ).pack(pady=(60, 15))

        tk.Label(
            inicio,
            text="Consulta tus productos y agrega nuevos desde la pestaña Inventario.",
            font=("Arial", 11),
            bg="white",
            wraplength=600
        ).pack()

        # Formulario del lado izquierdo
        formulario = tk.LabelFrame(
            inventario,
            text="Agregar producto",
            font=("Arial", 11, "bold"),
            bg="#EDF5F0",
            padx=15,
            pady=15
        )
        formulario.pack(
            side="left", fill="y",
            padx=15, pady=15
        )

        self.entry_nombre = self._crear_campo(
            formulario, "Nombre:"
        )
        self.entry_precio = self._crear_campo(
            formulario, "Precio ($):"
        )
        self.entry_stock = self._crear_campo(
            formulario, "Stock:"
        )

        tk.Button(
            formulario,
            text="Guardar producto",
            font=("Arial", 10, "bold"),
            bg="#378562",
            fg="white",
            relief="flat",
            cursor="hand2",
            pady=10,
            command=self._guardar_producto
        ).pack(fill="x", pady=15)

        # Tabla del lado derecho
        listado = tk.Frame(inventario, bg="#EDF5F0")
        listado.pack(
            side="left",
            fill="both",
            expand=True,
            padx=(0, 15),
            pady=15
        )

        ttk.Button(
            listado,
            text="Recargar lista",
            command=self._cargar_productos
        ).pack(anchor="e", pady=(0, 10))

        marco_tabla = tk.Frame(listado)
        marco_tabla.pack(fill="both", expand=True)

        self.tabla = ttk.Treeview(
            marco_tabla,
            columns=("id", "nombre", "precio", "stock"),
            show="headings"
        )

        self.tabla.heading("id", text="ID")
        self.tabla.heading("nombre", text="Nombre")
        self.tabla.heading("precio", text="Precio ($)")
        self.tabla.heading("stock", text="Stock")

        self.tabla.column("id", width=50, minwidth=40, anchor="center")
        self.tabla.column("nombre", width=220, minwidth=100, anchor="w")
        self.tabla.column("precio", width=100, minwidth=80, anchor="center")
        self.tabla.column("stock", width=70, minwidth=50, anchor="center")

        barra = ttk.Scrollbar(
            marco_tabla,
            orient="vertical",
            command=self.tabla.yview
        )
        self.tabla.configure(yscrollcommand=barra.set)

        barra.pack(side="right", fill="y")
        self.tabla.pack(side="left", fill="both", expand=True)

        # Mostrar los productos que ya existen en MySQL.
        self._cargar_productos()

    def _crear_campo(self, padre, texto):
        tk.Label(
            padre,
            text=texto,
            font=("Arial", 11),
            bg="#EDF5F0"
        ).pack(anchor="w")

        entrada = tk.Entry(
            padre,
            font=("Arial", 11),
            width=20
        )
        entrada.pack(fill="x", pady=(5, 15))

        return entrada

    def _cargar_productos(self):
        productos = Product().get_all()

        if productos is None:
            messagebox.showerror(
                "Error",
                "No se pudieron cargar los productos. Revisa la terminal."
            )
            return

        # Quitar las filas anteriores para no repetirlas.
        for fila in self.tabla.get_children():
            self.tabla.delete(fila)

        # Colocar cada producto en una fila.
        for producto in productos:
            self.tabla.insert(
                "",
                "end",
                values=(
                    producto["id_product"],
                    producto["nombre"],
                    f'{producto["precio"]:.2f}',
                    producto["stock"]
                )
            )

    def _guardar_producto(self):
        nombre = self.entry_nombre.get().strip()

        if not nombre or len(nombre) > 100:
            messagebox.showwarning(
                "Nombre incorrecto",
                "Escribe un nombre de 1 a 100 caracteres."
            )
            return

        try:
            precio = Decimal(self.entry_precio.get().strip())
            stock = int(self.entry_stock.get().strip())

            if not precio.is_finite():
                raise ValueError

            if not 0 <= precio <= Decimal("99999999.99"):
                raise ValueError

            if precio != precio.quantize(Decimal("0.01")):
                raise ValueError

            if not 0 <= stock <= 2147483647:
                raise ValueError

        except (InvalidOperation, ValueError):
            messagebox.showwarning(
                "Datos incorrectos",
                "Escribe un precio válido con máximo 2 decimales "
                "usando punto, por ejemplo: 350.50.\n"
                "El stock debe ser un número entero y no negativo."
            )
            return

        producto = Product(nombre, precio, stock)

        if producto.save():
            messagebox.showinfo(
                "Guardado",
                "Producto registrado correctamente."
            )

            self.entry_nombre.delete(0, tk.END)
            self.entry_precio.delete(0, tk.END)
            self.entry_stock.delete(0, tk.END)

            self._cargar_productos()
            self.entry_nombre.focus_set()

        else:
            messagebox.showerror(
                "Error",
                "No se pudo guardar el producto. Revisa la terminal."
            )

    def _cerrar_sesion(self):
        from Views.login_view import LoginVentana

        for widget in self.root.winfo_children():
            widget.destroy()

        LoginVentana(self.root)
