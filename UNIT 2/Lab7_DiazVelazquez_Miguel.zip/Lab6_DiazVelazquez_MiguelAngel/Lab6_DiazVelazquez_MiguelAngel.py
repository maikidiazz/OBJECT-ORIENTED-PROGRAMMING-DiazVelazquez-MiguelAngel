import os
from tkinter import *
from tkinter import ttk
import tkinter as tk

from abc import ABC, abstractmethod


class SmartDevice(ABC):
    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    def turn_on(self):
        pass

    @abstractmethod
    def turn_off(self):
        pass


class SmartLight(SmartDevice):
    def __init__(self):
        super().__init__("Bedroom Smart Light")

    def turn_on(self):
        return f"{self.name} set to 100% brightness"

    def turn_off(self):
        return f"{self.name} turned off"


class SmartSpeaker(SmartDevice):
    def __init__(self):
        super().__init__("Bluetooth Speaker")

    def turn_on(self):
        return f"{self.name} is now playing music"

    def turn_off(self):
        return f"{self.name} stopped playing music"


class SmartViewer(SmartDevice):
    def __init__(self):
        super().__init__("Security Camera")

    def turn_on(self):
        return f"{self.name} is now streaming video"

    def turn_off(self):
        return f"{self.name} stopped streaming video"


class SmartTV(SmartDevice):
    def __init__(self):
        super().__init__("Bedroom Smart TV")

    def turn_on(self):
        return f"{self.name} is now displaying Netflix"

    def turn_off(self):
        return f"{self.name} screen turned off"


class SmartHomeApp(tk.Tk):

    def __init__(self):
        super().__init__()

        self.title("Lab 6.1 - Smart Home Diaz Velazquez")
        self.geometry("600x650")
        self.resizable(False, False)

        dir_actual = os.path.dirname(os.path.abspath(__file__))
        icon_dir = os.path.join(dir_actual, "app_icon.png")

        if os.path.exists(icon_dir):
            self.app_icon = tk.PhotoImage(file=icon_dir)
            self.iconphoto(True, self.app_icon)
        else:
            print("Icon file not found. Using default icon.")

        self.items = {
            "Bedroom Light": SmartLight(),
            "Bluetooth Speaker": SmartSpeaker(),
            "Security Camera": SmartViewer(),
            "Bedroom TV": SmartTV()
        }

        self._build_interface()

    def _build_interface(self):

        lbl_header = tk.Label(
            self,
            text="My Smart Home",
            font=("Arial", 15, "bold"),
            fg="#2c3e50"
        )
        lbl_header.pack(pady=12)

        group_box = tk.LabelFrame(
            self,
            text=" Choose a Smart Device ",
            font=("Arial", 10, "bold"),
            padx=15,
            pady=10
        )
        group_box.pack(fill="x", padx=20, pady=5)

        first_key = list(self.items.keys())[0]

        self.selected_key = tk.StringVar(
            value=first_key
        )

        for key in self.items.keys():

            rb = ttk.Radiobutton(
                group_box,
                text=key,
                value=key,
                variable=self.selected_key
            )

            rb.pack(
                anchor="w",
                pady=3
            )

        button_frame = tk.Frame(self)
        button_frame.pack(pady=15)

        btn_on = tk.Button(
            button_frame,
            text="TURN ON",
            command=self._handle_turn_on,
            bg="#317c9b",
            fg="white",
            font=("Arial", 10, "bold"),
            cursor="hand2",
            padx=20,
            pady=6
        )

        btn_on.grid(
            row=0,
            column=0,
            padx=10
        )

        btn_off = tk.Button(
            button_frame,
            text="TURN OFF",
            command=self._handle_turn_off,
            bg="#b34f46",
            fg="white",
            font=("Arial", 10, "bold"),
            cursor="hand2",
            padx=20,
            pady=6
        )

        btn_off.grid(
            row=0,
            column=1,
            padx=10
        )

        self.lbl_output = tk.Label(
            self,
            text="Select a device and choose an action.",
            font=("Arial", 10, "italic"),
            bg="#ecf0f1",
            fg="#34495e",
            relief="groove",
            height=3,
            wraplength=420,
            justify="center"
        )

        self.lbl_output.pack(
            fill="x",
            padx=20,
            pady=5
        )

        lbl_log = tk.Label(
            self,
            text="Device Activity Log",
            font=("Arial", 11, "bold")
        )

        lbl_log.pack(pady=(15, 5))

        log_frame = tk.Frame(self)
        log_frame.pack(
            fill="both",
            padx=20
        )

        scrollbar = tk.Scrollbar(log_frame)

        scrollbar.pack(
            side="right",
            fill="y"
        )

        self.activity_log = tk.Listbox(
            log_frame,
            height=8,
            yscrollcommand=scrollbar.set
        )

        self.activity_log.pack(
            side="left",
            fill="both",
            expand=True
        )

        scrollbar.config(
            command=self.activity_log.yview
        )

    def _handle_turn_on(self):

        chosen_key = self.selected_key.get()

        active_object: SmartDevice = self.items[chosen_key]

        # POLYMORPHISM
        result_message = active_object.turn_on()

        self.lbl_output.config(
            text=result_message,
            font=("Arial", 10, "normal")
        )

        # Add to Device Activity Log
        self.activity_log.insert(
            tk.END,
            result_message
        )

        self.activity_log.see(tk.END)

    def _handle_turn_off(self):

        chosen_key = self.selected_key.get()

        active_object: SmartDevice = self.items[chosen_key]

        # POLYMORPHISM
        result_message = active_object.turn_off()

        self.lbl_output.config(
            text=result_message,
            font=("Arial", 10, "normal")
        )

        # Add to Device Activity Log
        self.activity_log.insert(
            tk.END,
            result_message
        )

        self.activity_log.see(tk.END)


if __name__ == "__main__":

    app = SmartHomeApp()

    app.mainloop()
